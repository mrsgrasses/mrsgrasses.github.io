function sayHello(){
alert("الموقع يعمل بنجاح 🚀");
}
